from .most_popular import MostPop
from .EASE_R import EASER
from .RP3beta import RP3beta
from .RendleMF_NeuMFvsMF import RendleMF
from .iALS import iALS
from .NeuMF import NeuMF
from .Proxy import ProxyRecommender
